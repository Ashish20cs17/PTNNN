import PracticeTimeLanding from "./PracticeTimeLanding";

export default PracticeTimeLanding;
